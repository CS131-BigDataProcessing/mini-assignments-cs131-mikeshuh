# About the package
This package provides functions to validate columns in a crime dataset and functions to provide the mean and median for the age column.

# Installation
In order to install this package, use pip:

```bash
pip install git+https://github.com/mikeshuh/crime_test.git
```