__version__ = '1.0'
from stats_function import age_mean, age_median
from validate_functions import validate_victim_sex, validate_victim_age
print("Thank you for installing this package.")